﻿namespace calendar_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_page_welcome_label = new System.Windows.Forms.Label();
            this.add_panel_button = new System.Windows.Forms.Button();
            this.cancel__panel_button = new System.Windows.Forms.Button();
            this.show__panel_button = new System.Windows.Forms.Button();
            this.search__panel_button = new System.Windows.Forms.Button();
            this.edit_panel_button = new System.Windows.Forms.Button();
            this.add_panel = new System.Windows.Forms.Panel();
            this.add_app_recurrenceEndDate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.add_app_recurrenceCount_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.add_app_recurrence_comboBox = new System.Windows.Forms.ComboBox();
            this.add_app_name_input = new System.Windows.Forms.TextBox();
            this.add_app_label_10 = new System.Windows.Forms.Label();
            this.add_app_label_11 = new System.Windows.Forms.Label();
            this.add_app_richTextBox = new System.Windows.Forms.RichTextBox();
            this.add_app_to_minutes_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.add_app_to_hours_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.add_app_label_9 = new System.Windows.Forms.Label();
            this.add_app_label_8 = new System.Windows.Forms.Label();
            this.add_app_label_7 = new System.Windows.Forms.Label();
            this.add_app_label_6 = new System.Windows.Forms.Label();
            this.add_app_from_minutes_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.add_app_label_5 = new System.Windows.Forms.Label();
            this.add_app_label_4 = new System.Windows.Forms.Label();
            this.add_app_from_hours_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.add_app_label_3 = new System.Windows.Forms.Label();
            this.add_app_label_2 = new System.Windows.Forms.Label();
            this.add_app_confirm_button = new System.Windows.Forms.Button();
            this.add_app_label_1 = new System.Windows.Forms.Label();
            this.add_app_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.add_app_welcome = new System.Windows.Forms.Label();
            this.exit_add_panel_button = new System.Windows.Forms.Button();
            this.add_app_take_a_look_panel = new System.Windows.Forms.Panel();
            this.add_app_take_a_look_label_2 = new System.Windows.Forms.Label();
            this.add_app_take_a_look_label_1 = new System.Windows.Forms.Label();
            this.add_app_take_a_look_button = new System.Windows.Forms.Button();
            this.exit_add_app_take_a_look = new System.Windows.Forms.Button();
            this.add_app_take_a_look_panel_welcome = new System.Windows.Forms.Label();
            this.cancel_panel = new System.Windows.Forms.Panel();
            this.cancel_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cancel_comboBox1 = new System.Windows.Forms.ComboBox();
            this.show_label2 = new System.Windows.Forms.Label();
            this.show_label1 = new System.Windows.Forms.Label();
            this.cancel_button1 = new System.Windows.Forms.Button();
            this.exit_cancel_panel_button = new System.Windows.Forms.Button();
            this.cancel_app_welcome = new System.Windows.Forms.Label();
            this.show_panel = new System.Windows.Forms.Panel();
            this.showing_app_panel = new System.Windows.Forms.Panel();
            this.showing_app_label1 = new System.Windows.Forms.Label();
            this.showing_app_label2 = new System.Windows.Forms.Label();
            this.showing_app_button2 = new System.Windows.Forms.Button();
            this.showing_app_label3 = new System.Windows.Forms.Label();
            this.show_app_button1 = new System.Windows.Forms.Button();
            this.show_label_1 = new System.Windows.Forms.Label();
            this.show_comboBox1 = new System.Windows.Forms.ComboBox();
            this.show_app_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.show_app_label_2 = new System.Windows.Forms.Label();
            this.show_app_welcome = new System.Windows.Forms.Label();
            this.exit_show_panel_button = new System.Windows.Forms.Button();
            this.edit_panel = new System.Windows.Forms.Panel();
            this.edit_app_panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.edit_take_a_look_panel = new System.Windows.Forms.Panel();
            this.edit_take_a_look_label1 = new System.Windows.Forms.Label();
            this.edit_take_a_look_label2 = new System.Windows.Forms.Label();
            this.edit_take_a_look_button2 = new System.Windows.Forms.Button();
            this.edit_take_a_look_label3 = new System.Windows.Forms.Label();
            this.edit_app_panel2_label5 = new System.Windows.Forms.Label();
            this.edit_app_richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.edit_app_panel2__to_min_numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.edit_app_panel2_to_hours_numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.edit_app_panel2_label6 = new System.Windows.Forms.Label();
            this.edit_app_panel2_label7 = new System.Windows.Forms.Label();
            this.edit_app_panel2_label8 = new System.Windows.Forms.Label();
            this.edit_app_panel2_label9 = new System.Windows.Forms.Label();
            this.edit_app_panel2_from_min_numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.edit_app_panel2__label10 = new System.Windows.Forms.Label();
            this.edit_app_panel2_label11 = new System.Windows.Forms.Label();
            this.edit_app_panel2_from_hours_numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.edit_app_panel2_label12 = new System.Windows.Forms.Label();
            this.edit_app_panel2_label13 = new System.Windows.Forms.Label();
            this.edit_app_panel2_button3 = new System.Windows.Forms.Button();
            this.edit_app_panel2__label14 = new System.Windows.Forms.Label();
            this.edit_app_panel2_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.edit_app_panel2_label15 = new System.Windows.Forms.Label();
            this.edit_app_panel2_button4 = new System.Windows.Forms.Button();
            this.edit_app_button1 = new System.Windows.Forms.Button();
            this.edit_app_comboBox1 = new System.Windows.Forms.ComboBox();
            this.edit_app_label2 = new System.Windows.Forms.Label();
            this.edit_app_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.edit_app_label1 = new System.Windows.Forms.Label();
            this.edit_app_welcome = new System.Windows.Forms.Label();
            this.exit_edit_panel_button = new System.Windows.Forms.Button();
            this.search_panel = new System.Windows.Forms.Panel();
            this.search_richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.search_button1 = new System.Windows.Forms.Button();
            this.search_textBox1 = new System.Windows.Forms.TextBox();
            this.search_app_welcome = new System.Windows.Forms.Label();
            this.exit_search_panel_button = new System.Windows.Forms.Button();
            this.add_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_recurrenceCount_numericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_to_minutes_numericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_to_hours_numericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_from_minutes_numericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_from_hours_numericUpDown)).BeginInit();
            this.add_app_take_a_look_panel.SuspendLayout();
            this.cancel_panel.SuspendLayout();
            this.show_panel.SuspendLayout();
            this.showing_app_panel.SuspendLayout();
            this.edit_panel.SuspendLayout();
            this.edit_app_panel2.SuspendLayout();
            this.edit_take_a_look_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2__to_min_numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2_to_hours_numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2_from_min_numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2_from_hours_numericUpDown4)).BeginInit();
            this.search_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // main_page_welcome_label
            // 
            this.main_page_welcome_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.main_page_welcome_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_page_welcome_label.Location = new System.Drawing.Point(133, 37);
            this.main_page_welcome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.main_page_welcome_label.Name = "main_page_welcome_label";
            this.main_page_welcome_label.Size = new System.Drawing.Size(399, 36);
            this.main_page_welcome_label.TabIndex = 0;
            this.main_page_welcome_label.Text = "Welcome! Please, choose an option!";
            this.main_page_welcome_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_panel_button
            // 
            this.add_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_panel_button.Location = new System.Drawing.Point(200, 123);
            this.add_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.add_panel_button.Name = "add_panel_button";
            this.add_panel_button.Size = new System.Drawing.Size(267, 37);
            this.add_panel_button.TabIndex = 1;
            this.add_panel_button.Text = "Add new appointment";
            this.add_panel_button.UseVisualStyleBackColor = true;
            this.add_panel_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // cancel__panel_button
            // 
            this.cancel__panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel__panel_button.Location = new System.Drawing.Point(200, 418);
            this.cancel__panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.cancel__panel_button.Name = "cancel__panel_button";
            this.cancel__panel_button.Size = new System.Drawing.Size(267, 37);
            this.cancel__panel_button.TabIndex = 2;
            this.cancel__panel_button.Text = "Cancel an appointment";
            this.cancel__panel_button.UseVisualStyleBackColor = true;
            this.cancel__panel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // show__panel_button
            // 
            this.show__panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.show__panel_button.Location = new System.Drawing.Point(200, 345);
            this.show__panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.show__panel_button.Name = "show__panel_button";
            this.show__panel_button.Size = new System.Drawing.Size(267, 37);
            this.show__panel_button.TabIndex = 3;
            this.show__panel_button.Text = "Show appointments";
            this.show__panel_button.UseVisualStyleBackColor = true;
            this.show__panel_button.Click += new System.EventHandler(this.show_button_Click);
            // 
            // search__panel_button
            // 
            this.search__panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search__panel_button.Location = new System.Drawing.Point(200, 271);
            this.search__panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.search__panel_button.Name = "search__panel_button";
            this.search__panel_button.Size = new System.Drawing.Size(267, 37);
            this.search__panel_button.TabIndex = 5;
            this.search__panel_button.Text = "Search an appointment";
            this.search__panel_button.UseVisualStyleBackColor = true;
            this.search__panel_button.Click += new System.EventHandler(this.search_button_Click);
            // 
            // edit_panel_button
            // 
            this.edit_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_panel_button.Location = new System.Drawing.Point(200, 197);
            this.edit_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.edit_panel_button.Name = "edit_panel_button";
            this.edit_panel_button.Size = new System.Drawing.Size(267, 37);
            this.edit_panel_button.TabIndex = 6;
            this.edit_panel_button.Text = "Edit an appointment";
            this.edit_panel_button.UseVisualStyleBackColor = true;
            this.edit_panel_button.Click += new System.EventHandler(this.edit_button_Click);
            // 
            // add_panel
            // 
            this.add_panel.Controls.Add(this.add_app_take_a_look_panel);
            this.add_panel.Controls.Add(this.add_app_recurrenceEndDate_dateTimePicker);
            this.add_panel.Controls.Add(this.label2);
            this.add_panel.Controls.Add(this.add_app_recurrenceCount_numericUpDown);
            this.add_panel.Controls.Add(this.add_app_recurrence_comboBox);
            this.add_panel.Controls.Add(this.add_app_name_input);
            this.add_panel.Controls.Add(this.add_app_label_10);
            this.add_panel.Controls.Add(this.add_app_label_11);
            this.add_panel.Controls.Add(this.add_app_richTextBox);
            this.add_panel.Controls.Add(this.add_app_to_minutes_numericUpDown);
            this.add_panel.Controls.Add(this.add_app_to_hours_numericUpDown);
            this.add_panel.Controls.Add(this.add_app_label_9);
            this.add_panel.Controls.Add(this.add_app_label_8);
            this.add_panel.Controls.Add(this.add_app_label_7);
            this.add_panel.Controls.Add(this.add_app_label_6);
            this.add_panel.Controls.Add(this.add_app_from_minutes_numericUpDown);
            this.add_panel.Controls.Add(this.add_app_label_5);
            this.add_panel.Controls.Add(this.add_app_label_4);
            this.add_panel.Controls.Add(this.add_app_from_hours_numericUpDown);
            this.add_panel.Controls.Add(this.add_app_label_3);
            this.add_panel.Controls.Add(this.add_app_label_2);
            this.add_panel.Controls.Add(this.add_app_confirm_button);
            this.add_panel.Controls.Add(this.add_app_label_1);
            this.add_panel.Controls.Add(this.add_app_dateTimePicker);
            this.add_panel.Controls.Add(this.add_app_welcome);
            this.add_panel.Controls.Add(this.exit_add_panel_button);
            this.add_panel.Location = new System.Drawing.Point(1, 0);
            this.add_panel.Margin = new System.Windows.Forms.Padding(4);
            this.add_panel.Name = "add_panel";
            this.add_panel.Size = new System.Drawing.Size(667, 615);
            this.add_panel.TabIndex = 4;
            this.add_panel.Visible = false;
            // 
            // add_app_recurrenceEndDate_dateTimePicker
            // 
            this.add_app_recurrenceEndDate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.add_app_recurrenceEndDate_dateTimePicker.Location = new System.Drawing.Point(11, 360);
            this.add_app_recurrenceEndDate_dateTimePicker.Name = "add_app_recurrenceEndDate_dateTimePicker";
            this.add_app_recurrenceEndDate_dateTimePicker.Size = new System.Drawing.Size(115, 22);
            this.add_app_recurrenceEndDate_dateTimePicker.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 16);
            this.label2.TabIndex = 25;
            this.label2.Text = "How many times";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // add_app_recurrenceCount_numericUpDown
            // 
            this.add_app_recurrenceCount_numericUpDown.Location = new System.Drawing.Point(14, 286);
            this.add_app_recurrenceCount_numericUpDown.Name = "add_app_recurrenceCount_numericUpDown";
            this.add_app_recurrenceCount_numericUpDown.Size = new System.Drawing.Size(52, 22);
            this.add_app_recurrenceCount_numericUpDown.TabIndex = 24;
            this.add_app_recurrenceCount_numericUpDown.ValueChanged += new System.EventHandler(this.add_app_recurrenceCount_numericUpDown_ValueChanged);
            // 
            // add_app_recurrence_comboBox
            // 
            this.add_app_recurrence_comboBox.FormattingEnabled = true;
            this.add_app_recurrence_comboBox.Items.AddRange(new object[] {
            "None",
            "Daily",
            "Weekly",
            "Monthly"});
            this.add_app_recurrence_comboBox.Location = new System.Drawing.Point(11, 225);
            this.add_app_recurrence_comboBox.Name = "add_app_recurrence_comboBox";
            this.add_app_recurrence_comboBox.Size = new System.Drawing.Size(121, 24);
            this.add_app_recurrence_comboBox.TabIndex = 23;
            this.add_app_recurrence_comboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // add_app_name_input
            // 
            this.add_app_name_input.Location = new System.Drawing.Point(200, 326);
            this.add_app_name_input.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_name_input.Name = "add_app_name_input";
            this.add_app_name_input.Size = new System.Drawing.Size(265, 22);
            this.add_app_name_input.TabIndex = 21;
            this.add_app_name_input.TextChanged += new System.EventHandler(this.add_app_name_input_TextChanged);
            // 
            // add_app_label_10
            // 
            this.add_app_label_10.Location = new System.Drawing.Point(200, 289);
            this.add_app_label_10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_10.Name = "add_app_label_10";
            this.add_app_label_10.Size = new System.Drawing.Size(267, 37);
            this.add_app_label_10.TabIndex = 20;
            this.add_app_label_10.Text = "Add a name for the event *";
            this.add_app_label_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_label_11
            // 
            this.add_app_label_11.Location = new System.Drawing.Point(200, 357);
            this.add_app_label_11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_11.Name = "add_app_label_11";
            this.add_app_label_11.Size = new System.Drawing.Size(267, 37);
            this.add_app_label_11.TabIndex = 19;
            this.add_app_label_11.Text = "Add a description for the event:";
            this.add_app_label_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_richTextBox
            // 
            this.add_app_richTextBox.Location = new System.Drawing.Point(133, 394);
            this.add_app_richTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_richTextBox.Name = "add_app_richTextBox";
            this.add_app_richTextBox.Size = new System.Drawing.Size(399, 54);
            this.add_app_richTextBox.TabIndex = 18;
            this.add_app_richTextBox.Text = "";
            this.add_app_richTextBox.TextChanged += new System.EventHandler(this.add_app_richTextBox_TextChanged);
            // 
            // add_app_to_minutes_numericUpDown
            // 
            this.add_app_to_minutes_numericUpDown.Location = new System.Drawing.Point(360, 258);
            this.add_app_to_minutes_numericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_to_minutes_numericUpDown.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.add_app_to_minutes_numericUpDown.Name = "add_app_to_minutes_numericUpDown";
            this.add_app_to_minutes_numericUpDown.Size = new System.Drawing.Size(53, 22);
            this.add_app_to_minutes_numericUpDown.TabIndex = 16;
            this.add_app_to_minutes_numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.add_app_to_minutes_numericUpDown.ValueChanged += new System.EventHandler(this.add_app_to_minutes_numericUpDown_ValueChanged);
            // 
            // add_app_to_hours_numericUpDown
            // 
            this.add_app_to_hours_numericUpDown.Location = new System.Drawing.Point(233, 258);
            this.add_app_to_hours_numericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_to_hours_numericUpDown.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.add_app_to_hours_numericUpDown.Name = "add_app_to_hours_numericUpDown";
            this.add_app_to_hours_numericUpDown.Size = new System.Drawing.Size(53, 22);
            this.add_app_to_hours_numericUpDown.TabIndex = 15;
            this.add_app_to_hours_numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.add_app_to_hours_numericUpDown.ValueChanged += new System.EventHandler(this.add_app_to_hours_numericUpDown_ValueChanged);
            // 
            // add_app_label_9
            // 
            this.add_app_label_9.Location = new System.Drawing.Point(187, 258);
            this.add_app_label_9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_9.Name = "add_app_label_9";
            this.add_app_label_9.Size = new System.Drawing.Size(47, 25);
            this.add_app_label_9.TabIndex = 14;
            this.add_app_label_9.Text = "To:";
            this.add_app_label_9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // add_app_label_8
            // 
            this.add_app_label_8.Location = new System.Drawing.Point(287, 258);
            this.add_app_label_8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_8.Name = "add_app_label_8";
            this.add_app_label_8.Size = new System.Drawing.Size(77, 25);
            this.add_app_label_8.TabIndex = 13;
            this.add_app_label_8.Text = "hours and ";
            this.add_app_label_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_label_7
            // 
            this.add_app_label_7.Location = new System.Drawing.Point(417, 258);
            this.add_app_label_7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_7.Name = "add_app_label_7";
            this.add_app_label_7.Size = new System.Drawing.Size(61, 25);
            this.add_app_label_7.TabIndex = 12;
            this.add_app_label_7.Text = "minutes.";
            this.add_app_label_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // add_app_label_6
            // 
            this.add_app_label_6.Location = new System.Drawing.Point(417, 209);
            this.add_app_label_6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_6.Name = "add_app_label_6";
            this.add_app_label_6.Size = new System.Drawing.Size(61, 25);
            this.add_app_label_6.TabIndex = 11;
            this.add_app_label_6.Text = "minutes.";
            this.add_app_label_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // add_app_from_minutes_numericUpDown
            // 
            this.add_app_from_minutes_numericUpDown.Location = new System.Drawing.Point(360, 209);
            this.add_app_from_minutes_numericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_from_minutes_numericUpDown.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.add_app_from_minutes_numericUpDown.Name = "add_app_from_minutes_numericUpDown";
            this.add_app_from_minutes_numericUpDown.Size = new System.Drawing.Size(53, 22);
            this.add_app_from_minutes_numericUpDown.TabIndex = 10;
            this.add_app_from_minutes_numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.add_app_from_minutes_numericUpDown.ValueChanged += new System.EventHandler(this.add_app_from_minutes_numericUpDown_ValueChanged);
            // 
            // add_app_label_5
            // 
            this.add_app_label_5.Location = new System.Drawing.Point(287, 209);
            this.add_app_label_5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_5.Name = "add_app_label_5";
            this.add_app_label_5.Size = new System.Drawing.Size(77, 25);
            this.add_app_label_5.TabIndex = 9;
            this.add_app_label_5.Text = "hours and ";
            this.add_app_label_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_label_4
            // 
            this.add_app_label_4.Location = new System.Drawing.Point(187, 209);
            this.add_app_label_4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_4.Name = "add_app_label_4";
            this.add_app_label_4.Size = new System.Drawing.Size(47, 25);
            this.add_app_label_4.TabIndex = 8;
            this.add_app_label_4.Text = "From:";
            this.add_app_label_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // add_app_from_hours_numericUpDown
            // 
            this.add_app_from_hours_numericUpDown.Location = new System.Drawing.Point(233, 209);
            this.add_app_from_hours_numericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_from_hours_numericUpDown.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.add_app_from_hours_numericUpDown.Name = "add_app_from_hours_numericUpDown";
            this.add_app_from_hours_numericUpDown.Size = new System.Drawing.Size(53, 22);
            this.add_app_from_hours_numericUpDown.TabIndex = 7;
            this.add_app_from_hours_numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.add_app_from_hours_numericUpDown.ValueChanged += new System.EventHandler(this.add_app__from_hours_numericUpDown_ValueChanged);
            // 
            // add_app_label_3
            // 
            this.add_app_label_3.Location = new System.Drawing.Point(133, 172);
            this.add_app_label_3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_3.Name = "add_app_label_3";
            this.add_app_label_3.Size = new System.Drawing.Size(400, 37);
            this.add_app_label_3.TabIndex = 6;
            this.add_app_label_3.Text = "Please, choose the time*";
            this.add_app_label_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_label_2
            // 
            this.add_app_label_2.AutoSize = true;
            this.add_app_label_2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.add_app_label_2.Location = new System.Drawing.Point(512, 534);
            this.add_app_label_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_2.Name = "add_app_label_2";
            this.add_app_label_2.Size = new System.Drawing.Size(107, 16);
            this.add_app_label_2.TabIndex = 5;
            this.add_app_label_2.Text = "* - required fileds";
            this.add_app_label_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_confirm_button
            // 
            this.add_app_confirm_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.add_app_confirm_button.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.add_app_confirm_button.Location = new System.Drawing.Point(233, 468);
            this.add_app_confirm_button.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_confirm_button.Name = "add_app_confirm_button";
            this.add_app_confirm_button.Size = new System.Drawing.Size(200, 37);
            this.add_app_confirm_button.TabIndex = 4;
            this.add_app_confirm_button.Text = "Confirm an appointment";
            this.add_app_confirm_button.UseVisualStyleBackColor = false;
            this.add_app_confirm_button.Click += new System.EventHandler(this.add_app_confirm_button_Click);
            // 
            // add_app_label_1
            // 
            this.add_app_label_1.Location = new System.Drawing.Point(200, 111);
            this.add_app_label_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_label_1.Name = "add_app_label_1";
            this.add_app_label_1.Size = new System.Drawing.Size(267, 37);
            this.add_app_label_1.TabIndex = 3;
            this.add_app_label_1.Text = "Please, choose the date*";
            this.add_app_label_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_dateTimePicker
            // 
            this.add_app_dateTimePicker.Location = new System.Drawing.Point(200, 148);
            this.add_app_dateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_dateTimePicker.Name = "add_app_dateTimePicker";
            this.add_app_dateTimePicker.Size = new System.Drawing.Size(265, 22);
            this.add_app_dateTimePicker.TabIndex = 2;
            this.add_app_dateTimePicker.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            this.add_app_dateTimePicker.ValueChanged += new System.EventHandler(this.add_app_dateTimePicker1_ValueChanged);
            // 
            // add_app_welcome
            // 
            this.add_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.add_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.add_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_welcome.Name = "add_app_welcome";
            this.add_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.add_app_welcome.TabIndex = 1;
            this.add_app_welcome.Text = "Please, add your appointment";
            this.add_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_add_panel_button
            // 
            this.exit_add_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_add_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_add_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_add_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.exit_add_panel_button.Name = "exit_add_panel_button";
            this.exit_add_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_add_panel_button.TabIndex = 0;
            this.exit_add_panel_button.Text = "Exit";
            this.exit_add_panel_button.UseVisualStyleBackColor = true;
            this.exit_add_panel_button.Click += new System.EventHandler(this.exit_add_panel_button_Click);
            // 
            // add_app_take_a_look_panel
            // 
            this.add_app_take_a_look_panel.Controls.Add(this.add_app_take_a_look_label_2);
            this.add_app_take_a_look_panel.Controls.Add(this.add_app_take_a_look_label_1);
            this.add_app_take_a_look_panel.Controls.Add(this.add_app_take_a_look_button);
            this.add_app_take_a_look_panel.Controls.Add(this.exit_add_app_take_a_look);
            this.add_app_take_a_look_panel.Controls.Add(this.add_app_take_a_look_panel_welcome);
            this.add_app_take_a_look_panel.Location = new System.Drawing.Point(0, 0);
            this.add_app_take_a_look_panel.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_take_a_look_panel.Name = "add_app_take_a_look_panel";
            this.add_app_take_a_look_panel.Size = new System.Drawing.Size(667, 615);
            this.add_app_take_a_look_panel.TabIndex = 22;
            this.add_app_take_a_look_panel.Visible = false;
            this.add_app_take_a_look_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.add_app_take_a_look_panel_Paint);
            // 
            // add_app_take_a_look_label_2
            // 
            this.add_app_take_a_look_label_2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.add_app_take_a_look_label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_app_take_a_look_label_2.Location = new System.Drawing.Point(133, 252);
            this.add_app_take_a_look_label_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_take_a_look_label_2.Name = "add_app_take_a_look_label_2";
            this.add_app_take_a_look_label_2.Size = new System.Drawing.Size(400, 111);
            this.add_app_take_a_look_label_2.TabIndex = 6;
            this.add_app_take_a_look_label_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_take_a_look_label_1
            // 
            this.add_app_take_a_look_label_1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.add_app_take_a_look_label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_app_take_a_look_label_1.Location = new System.Drawing.Point(133, 123);
            this.add_app_take_a_look_label_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_take_a_look_label_1.Name = "add_app_take_a_look_label_1";
            this.add_app_take_a_look_label_1.Size = new System.Drawing.Size(400, 111);
            this.add_app_take_a_look_label_1.TabIndex = 5;
            this.add_app_take_a_look_label_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_app_take_a_look_button
            // 
            this.add_app_take_a_look_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.add_app_take_a_look_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_app_take_a_look_button.Location = new System.Drawing.Point(233, 471);
            this.add_app_take_a_look_button.Margin = new System.Windows.Forms.Padding(4);
            this.add_app_take_a_look_button.Name = "add_app_take_a_look_button";
            this.add_app_take_a_look_button.Size = new System.Drawing.Size(200, 37);
            this.add_app_take_a_look_button.TabIndex = 4;
            this.add_app_take_a_look_button.Text = "Add another one";
            this.add_app_take_a_look_button.UseMnemonic = false;
            this.add_app_take_a_look_button.UseVisualStyleBackColor = true;
            this.add_app_take_a_look_button.Click += new System.EventHandler(this.add_app_take_a_look_button_Click);
            // 
            // exit_add_app_take_a_look
            // 
            this.exit_add_app_take_a_look.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_add_app_take_a_look.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_add_app_take_a_look.Location = new System.Drawing.Point(287, 516);
            this.exit_add_app_take_a_look.Margin = new System.Windows.Forms.Padding(4);
            this.exit_add_app_take_a_look.Name = "exit_add_app_take_a_look";
            this.exit_add_app_take_a_look.Size = new System.Drawing.Size(93, 37);
            this.exit_add_app_take_a_look.TabIndex = 3;
            this.exit_add_app_take_a_look.Text = "Exit";
            this.exit_add_app_take_a_look.UseMnemonic = false;
            this.exit_add_app_take_a_look.UseVisualStyleBackColor = true;
            this.exit_add_app_take_a_look.Click += new System.EventHandler(this.exit_add_app_take_a_look_panel_Click);
            // 
            // add_app_take_a_look_panel_welcome
            // 
            this.add_app_take_a_look_panel_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.add_app_take_a_look_panel_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_app_take_a_look_panel_welcome.Location = new System.Drawing.Point(133, 37);
            this.add_app_take_a_look_panel_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_take_a_look_panel_welcome.Name = "add_app_take_a_look_panel_welcome";
            this.add_app_take_a_look_panel_welcome.Size = new System.Drawing.Size(399, 36);
            this.add_app_take_a_look_panel_welcome.TabIndex = 2;
            this.add_app_take_a_look_panel_welcome.Text = "Take a look at your appointment!";
            this.add_app_take_a_look_panel_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cancel_panel
            // 
            this.cancel_panel.Controls.Add(this.cancel_dateTimePicker1);
            this.cancel_panel.Controls.Add(this.cancel_comboBox1);
            this.cancel_panel.Controls.Add(this.show_label2);
            this.cancel_panel.Controls.Add(this.show_label1);
            this.cancel_panel.Controls.Add(this.cancel_button1);
            this.cancel_panel.Controls.Add(this.exit_cancel_panel_button);
            this.cancel_panel.Controls.Add(this.cancel_app_welcome);
            this.cancel_panel.Location = new System.Drawing.Point(0, 0);
            this.cancel_panel.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_panel.Name = "cancel_panel";
            this.cancel_panel.Size = new System.Drawing.Size(667, 615);
            this.cancel_panel.TabIndex = 7;
            this.cancel_panel.Visible = false;
            // 
            // cancel_dateTimePicker1
            // 
            this.cancel_dateTimePicker1.Location = new System.Drawing.Point(200, 148);
            this.cancel_dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_dateTimePicker1.Name = "cancel_dateTimePicker1";
            this.cancel_dateTimePicker1.Size = new System.Drawing.Size(265, 22);
            this.cancel_dateTimePicker1.TabIndex = 13;
            this.cancel_dateTimePicker1.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            this.cancel_dateTimePicker1.ValueChanged += new System.EventHandler(this.cancel_dateTimePicker1_ValueChanged);
            // 
            // cancel_comboBox1
            // 
            this.cancel_comboBox1.FormattingEnabled = true;
            this.cancel_comboBox1.Location = new System.Drawing.Point(200, 209);
            this.cancel_comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_comboBox1.Name = "cancel_comboBox1";
            this.cancel_comboBox1.Size = new System.Drawing.Size(265, 24);
            this.cancel_comboBox1.TabIndex = 12;
            this.cancel_comboBox1.SelectedIndexChanged += new System.EventHandler(this.cancel_comboBox1_SelectedIndexChanged);
            // 
            // show_label2
            // 
            this.show_label2.Location = new System.Drawing.Point(133, 172);
            this.show_label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.show_label2.Name = "show_label2";
            this.show_label2.Size = new System.Drawing.Size(400, 37);
            this.show_label2.TabIndex = 11;
            this.show_label2.Text = "Please, choose the appoinment to show";
            this.show_label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // show_label1
            // 
            this.show_label1.Location = new System.Drawing.Point(200, 111);
            this.show_label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.show_label1.Name = "show_label1";
            this.show_label1.Size = new System.Drawing.Size(267, 37);
            this.show_label1.TabIndex = 10;
            this.show_label1.Text = "Please, choose the date";
            this.show_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cancel_button1
            // 
            this.cancel_button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel_button1.Location = new System.Drawing.Point(200, 246);
            this.cancel_button1.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_button1.Name = "cancel_button1";
            this.cancel_button1.Size = new System.Drawing.Size(267, 37);
            this.cancel_button1.TabIndex = 9;
            this.cancel_button1.Text = "Cancel the appointment";
            this.cancel_button1.UseVisualStyleBackColor = true;
            this.cancel_button1.Click += new System.EventHandler(this.cancel_button1_Click);
            // 
            // exit_cancel_panel_button
            // 
            this.exit_cancel_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_cancel_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_cancel_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_cancel_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.exit_cancel_panel_button.Name = "exit_cancel_panel_button";
            this.exit_cancel_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_cancel_panel_button.TabIndex = 3;
            this.exit_cancel_panel_button.Text = "Exit";
            this.exit_cancel_panel_button.UseVisualStyleBackColor = true;
            this.exit_cancel_panel_button.Click += new System.EventHandler(this.exit_cancel_panel_button_Click);
            // 
            // cancel_app_welcome
            // 
            this.cancel_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cancel_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.cancel_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cancel_app_welcome.Name = "cancel_app_welcome";
            this.cancel_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.cancel_app_welcome.TabIndex = 2;
            this.cancel_app_welcome.Text = "Please, choose an appointment to be canceled";
            this.cancel_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // show_panel
            // 
            this.show_panel.Controls.Add(this.showing_app_panel);
            this.show_panel.Controls.Add(this.show_app_button1);
            this.show_panel.Controls.Add(this.show_label_1);
            this.show_panel.Controls.Add(this.show_comboBox1);
            this.show_panel.Controls.Add(this.show_app_dateTimePicker);
            this.show_panel.Controls.Add(this.show_app_label_2);
            this.show_panel.Controls.Add(this.show_app_welcome);
            this.show_panel.Controls.Add(this.exit_show_panel_button);
            this.show_panel.Location = new System.Drawing.Point(0, 0);
            this.show_panel.Margin = new System.Windows.Forms.Padding(4);
            this.show_panel.Name = "show_panel";
            this.show_panel.Size = new System.Drawing.Size(667, 615);
            this.show_panel.TabIndex = 8;
            this.show_panel.Visible = false;
            // 
            // showing_app_panel
            // 
            this.showing_app_panel.Controls.Add(this.showing_app_label1);
            this.showing_app_panel.Controls.Add(this.showing_app_label2);
            this.showing_app_panel.Controls.Add(this.showing_app_button2);
            this.showing_app_panel.Controls.Add(this.showing_app_label3);
            this.showing_app_panel.Location = new System.Drawing.Point(0, 0);
            this.showing_app_panel.Margin = new System.Windows.Forms.Padding(4);
            this.showing_app_panel.Name = "showing_app_panel";
            this.showing_app_panel.Size = new System.Drawing.Size(667, 615);
            this.showing_app_panel.TabIndex = 23;
            this.showing_app_panel.Visible = false;
            // 
            // showing_app_label1
            // 
            this.showing_app_label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.showing_app_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showing_app_label1.Location = new System.Drawing.Point(133, 252);
            this.showing_app_label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.showing_app_label1.Name = "showing_app_label1";
            this.showing_app_label1.Size = new System.Drawing.Size(400, 111);
            this.showing_app_label1.TabIndex = 6;
            this.showing_app_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showing_app_label2
            // 
            this.showing_app_label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.showing_app_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showing_app_label2.Location = new System.Drawing.Point(133, 123);
            this.showing_app_label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.showing_app_label2.Name = "showing_app_label2";
            this.showing_app_label2.Size = new System.Drawing.Size(400, 111);
            this.showing_app_label2.TabIndex = 5;
            this.showing_app_label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showing_app_button2
            // 
            this.showing_app_button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.showing_app_button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.showing_app_button2.Location = new System.Drawing.Point(287, 516);
            this.showing_app_button2.Margin = new System.Windows.Forms.Padding(4);
            this.showing_app_button2.Name = "showing_app_button2";
            this.showing_app_button2.Size = new System.Drawing.Size(93, 37);
            this.showing_app_button2.TabIndex = 3;
            this.showing_app_button2.Text = "Exit";
            this.showing_app_button2.UseMnemonic = false;
            this.showing_app_button2.UseVisualStyleBackColor = true;
            this.showing_app_button2.Click += new System.EventHandler(this.showing_the_app_button2_Click);
            // 
            // showing_app_label3
            // 
            this.showing_app_label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.showing_app_label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showing_app_label3.Location = new System.Drawing.Point(133, 37);
            this.showing_app_label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.showing_app_label3.Name = "showing_app_label3";
            this.showing_app_label3.Size = new System.Drawing.Size(399, 36);
            this.showing_app_label3.TabIndex = 2;
            this.showing_app_label3.Text = "Take a look at your appointment!";
            this.showing_app_label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // show_app_button1
            // 
            this.show_app_button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.show_app_button1.Location = new System.Drawing.Point(267, 246);
            this.show_app_button1.Margin = new System.Windows.Forms.Padding(4);
            this.show_app_button1.Name = "show_app_button1";
            this.show_app_button1.Size = new System.Drawing.Size(133, 37);
            this.show_app_button1.TabIndex = 8;
            this.show_app_button1.Text = "Show";
            this.show_app_button1.UseVisualStyleBackColor = true;
            this.show_app_button1.Click += new System.EventHandler(this.show_app_button1_Click);
            // 
            // show_label_1
            // 
            this.show_label_1.Location = new System.Drawing.Point(133, 172);
            this.show_label_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.show_label_1.Name = "show_label_1";
            this.show_label_1.Size = new System.Drawing.Size(400, 37);
            this.show_label_1.TabIndex = 7;
            this.show_label_1.Text = "Please, choose the appoinment to show";
            this.show_label_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // show_comboBox1
            // 
            this.show_comboBox1.FormattingEnabled = true;
            this.show_comboBox1.Location = new System.Drawing.Point(200, 209);
            this.show_comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.show_comboBox1.Name = "show_comboBox1";
            this.show_comboBox1.Size = new System.Drawing.Size(265, 24);
            this.show_comboBox1.TabIndex = 6;
            this.show_comboBox1.SelectedIndexChanged += new System.EventHandler(this.show_comboBox1_SelectedIndexChanged);
            // 
            // show_app_dateTimePicker
            // 
            this.show_app_dateTimePicker.Location = new System.Drawing.Point(200, 148);
            this.show_app_dateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.show_app_dateTimePicker.Name = "show_app_dateTimePicker";
            this.show_app_dateTimePicker.Size = new System.Drawing.Size(265, 22);
            this.show_app_dateTimePicker.TabIndex = 5;
            this.show_app_dateTimePicker.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            this.show_app_dateTimePicker.ValueChanged += new System.EventHandler(this.show_app_dateTimePicker_ValueChanged);
            // 
            // show_app_label_2
            // 
            this.show_app_label_2.Location = new System.Drawing.Point(200, 111);
            this.show_app_label_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.show_app_label_2.Name = "show_app_label_2";
            this.show_app_label_2.Size = new System.Drawing.Size(267, 37);
            this.show_app_label_2.TabIndex = 4;
            this.show_app_label_2.Text = "Please, choose the date";
            this.show_app_label_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // show_app_welcome
            // 
            this.show_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.show_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.show_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.show_app_welcome.Name = "show_app_welcome";
            this.show_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.show_app_welcome.TabIndex = 2;
            this.show_app_welcome.Text = "Please, choose a date";
            this.show_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_show_panel_button
            // 
            this.exit_show_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_show_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_show_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_show_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.exit_show_panel_button.Name = "exit_show_panel_button";
            this.exit_show_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_show_panel_button.TabIndex = 1;
            this.exit_show_panel_button.Text = "Exit";
            this.exit_show_panel_button.UseVisualStyleBackColor = true;
            this.exit_show_panel_button.Click += new System.EventHandler(this.show_app_panel_button_Click);
            // 
            // edit_panel
            // 
            this.edit_panel.Controls.Add(this.edit_app_panel2);
            this.edit_panel.Controls.Add(this.edit_app_button1);
            this.edit_panel.Controls.Add(this.edit_app_comboBox1);
            this.edit_panel.Controls.Add(this.edit_app_label2);
            this.edit_panel.Controls.Add(this.edit_app_dateTimePicker1);
            this.edit_panel.Controls.Add(this.edit_app_label1);
            this.edit_panel.Controls.Add(this.edit_app_welcome);
            this.edit_panel.Controls.Add(this.exit_edit_panel_button);
            this.edit_panel.Location = new System.Drawing.Point(0, 0);
            this.edit_panel.Margin = new System.Windows.Forms.Padding(4);
            this.edit_panel.Name = "edit_panel";
            this.edit_panel.Size = new System.Drawing.Size(667, 615);
            this.edit_panel.TabIndex = 9;
            this.edit_panel.Visible = false;
            // 
            // edit_app_panel2
            // 
            this.edit_app_panel2.Controls.Add(this.label1);
            this.edit_app_panel2.Controls.Add(this.edit_take_a_look_panel);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label5);
            this.edit_app_panel2.Controls.Add(this.edit_app_richTextBox1);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2__to_min_numericUpDown1);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_to_hours_numericUpDown2);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label6);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label7);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label8);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label9);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_from_min_numericUpDown3);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2__label10);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label11);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_from_hours_numericUpDown4);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label12);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label13);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_button3);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2__label14);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_dateTimePicker1);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_label15);
            this.edit_app_panel2.Controls.Add(this.edit_app_panel2_button4);
            this.edit_app_panel2.Location = new System.Drawing.Point(0, 0);
            this.edit_app_panel2.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2.Name = "edit_app_panel2";
            this.edit_app_panel2.Size = new System.Drawing.Size(667, 615);
            this.edit_app_panel2.TabIndex = 11;
            this.edit_app_panel2.Visible = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(133, 412);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 37);
            this.label1.TabIndex = 24;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_take_a_look_panel
            // 
            this.edit_take_a_look_panel.Controls.Add(this.edit_take_a_look_label1);
            this.edit_take_a_look_panel.Controls.Add(this.edit_take_a_look_label2);
            this.edit_take_a_look_panel.Controls.Add(this.edit_take_a_look_button2);
            this.edit_take_a_look_panel.Controls.Add(this.edit_take_a_look_label3);
            this.edit_take_a_look_panel.Location = new System.Drawing.Point(0, 0);
            this.edit_take_a_look_panel.Margin = new System.Windows.Forms.Padding(4);
            this.edit_take_a_look_panel.Name = "edit_take_a_look_panel";
            this.edit_take_a_look_panel.Size = new System.Drawing.Size(667, 615);
            this.edit_take_a_look_panel.TabIndex = 23;
            this.edit_take_a_look_panel.Visible = false;
            // 
            // edit_take_a_look_label1
            // 
            this.edit_take_a_look_label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.edit_take_a_look_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_take_a_look_label1.Location = new System.Drawing.Point(133, 252);
            this.edit_take_a_look_label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_take_a_look_label1.Name = "edit_take_a_look_label1";
            this.edit_take_a_look_label1.Size = new System.Drawing.Size(400, 111);
            this.edit_take_a_look_label1.TabIndex = 6;
            this.edit_take_a_look_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_take_a_look_label2
            // 
            this.edit_take_a_look_label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.edit_take_a_look_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_take_a_look_label2.Location = new System.Drawing.Point(133, 123);
            this.edit_take_a_look_label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_take_a_look_label2.Name = "edit_take_a_look_label2";
            this.edit_take_a_look_label2.Size = new System.Drawing.Size(400, 111);
            this.edit_take_a_look_label2.TabIndex = 5;
            this.edit_take_a_look_label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_take_a_look_button2
            // 
            this.edit_take_a_look_button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.edit_take_a_look_button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_take_a_look_button2.Location = new System.Drawing.Point(287, 516);
            this.edit_take_a_look_button2.Margin = new System.Windows.Forms.Padding(4);
            this.edit_take_a_look_button2.Name = "edit_take_a_look_button2";
            this.edit_take_a_look_button2.Size = new System.Drawing.Size(93, 37);
            this.edit_take_a_look_button2.TabIndex = 3;
            this.edit_take_a_look_button2.Text = "Exit";
            this.edit_take_a_look_button2.UseMnemonic = false;
            this.edit_take_a_look_button2.UseVisualStyleBackColor = true;
            this.edit_take_a_look_button2.Click += new System.EventHandler(this.edit_take_a_look_button2_Click);
            // 
            // edit_take_a_look_label3
            // 
            this.edit_take_a_look_label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.edit_take_a_look_label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_take_a_look_label3.Location = new System.Drawing.Point(133, 37);
            this.edit_take_a_look_label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_take_a_look_label3.Name = "edit_take_a_look_label3";
            this.edit_take_a_look_label3.Size = new System.Drawing.Size(399, 36);
            this.edit_take_a_look_label3.TabIndex = 2;
            this.edit_take_a_look_label3.Text = "Take a look at your appointment!";
            this.edit_take_a_look_label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_label5
            // 
            this.edit_app_panel2_label5.Location = new System.Drawing.Point(200, 295);
            this.edit_app_panel2_label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label5.Name = "edit_app_panel2_label5";
            this.edit_app_panel2_label5.Size = new System.Drawing.Size(267, 37);
            this.edit_app_panel2_label5.TabIndex = 19;
            this.edit_app_panel2_label5.Text = "Please, change the description for the event:";
            this.edit_app_panel2_label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_richTextBox1
            // 
            this.edit_app_richTextBox1.Location = new System.Drawing.Point(133, 332);
            this.edit_app_richTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_richTextBox1.Name = "edit_app_richTextBox1";
            this.edit_app_richTextBox1.Size = new System.Drawing.Size(399, 54);
            this.edit_app_richTextBox1.TabIndex = 18;
            this.edit_app_richTextBox1.Text = "";
            // 
            // edit_app_panel2__to_min_numericUpDown1
            // 
            this.edit_app_panel2__to_min_numericUpDown1.Location = new System.Drawing.Point(360, 258);
            this.edit_app_panel2__to_min_numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2__to_min_numericUpDown1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.edit_app_panel2__to_min_numericUpDown1.Name = "edit_app_panel2__to_min_numericUpDown1";
            this.edit_app_panel2__to_min_numericUpDown1.Size = new System.Drawing.Size(53, 22);
            this.edit_app_panel2__to_min_numericUpDown1.TabIndex = 16;
            this.edit_app_panel2__to_min_numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // edit_app_panel2_to_hours_numericUpDown2
            // 
            this.edit_app_panel2_to_hours_numericUpDown2.Location = new System.Drawing.Point(233, 258);
            this.edit_app_panel2_to_hours_numericUpDown2.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2_to_hours_numericUpDown2.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.edit_app_panel2_to_hours_numericUpDown2.Name = "edit_app_panel2_to_hours_numericUpDown2";
            this.edit_app_panel2_to_hours_numericUpDown2.Size = new System.Drawing.Size(53, 22);
            this.edit_app_panel2_to_hours_numericUpDown2.TabIndex = 15;
            this.edit_app_panel2_to_hours_numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // edit_app_panel2_label6
            // 
            this.edit_app_panel2_label6.Location = new System.Drawing.Point(187, 258);
            this.edit_app_panel2_label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label6.Name = "edit_app_panel2_label6";
            this.edit_app_panel2_label6.Size = new System.Drawing.Size(47, 25);
            this.edit_app_panel2_label6.TabIndex = 14;
            this.edit_app_panel2_label6.Text = "To:";
            this.edit_app_panel2_label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // edit_app_panel2_label7
            // 
            this.edit_app_panel2_label7.Location = new System.Drawing.Point(287, 258);
            this.edit_app_panel2_label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label7.Name = "edit_app_panel2_label7";
            this.edit_app_panel2_label7.Size = new System.Drawing.Size(77, 25);
            this.edit_app_panel2_label7.TabIndex = 13;
            this.edit_app_panel2_label7.Text = "hours and ";
            this.edit_app_panel2_label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_label8
            // 
            this.edit_app_panel2_label8.Location = new System.Drawing.Point(417, 258);
            this.edit_app_panel2_label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label8.Name = "edit_app_panel2_label8";
            this.edit_app_panel2_label8.Size = new System.Drawing.Size(61, 25);
            this.edit_app_panel2_label8.TabIndex = 12;
            this.edit_app_panel2_label8.Text = "minutes.";
            this.edit_app_panel2_label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edit_app_panel2_label9
            // 
            this.edit_app_panel2_label9.Location = new System.Drawing.Point(417, 209);
            this.edit_app_panel2_label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label9.Name = "edit_app_panel2_label9";
            this.edit_app_panel2_label9.Size = new System.Drawing.Size(61, 25);
            this.edit_app_panel2_label9.TabIndex = 11;
            this.edit_app_panel2_label9.Text = "minutes.";
            this.edit_app_panel2_label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edit_app_panel2_from_min_numericUpDown3
            // 
            this.edit_app_panel2_from_min_numericUpDown3.Location = new System.Drawing.Point(360, 209);
            this.edit_app_panel2_from_min_numericUpDown3.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2_from_min_numericUpDown3.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.edit_app_panel2_from_min_numericUpDown3.Name = "edit_app_panel2_from_min_numericUpDown3";
            this.edit_app_panel2_from_min_numericUpDown3.Size = new System.Drawing.Size(53, 22);
            this.edit_app_panel2_from_min_numericUpDown3.TabIndex = 10;
            this.edit_app_panel2_from_min_numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // edit_app_panel2__label10
            // 
            this.edit_app_panel2__label10.Location = new System.Drawing.Point(287, 209);
            this.edit_app_panel2__label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2__label10.Name = "edit_app_panel2__label10";
            this.edit_app_panel2__label10.Size = new System.Drawing.Size(77, 25);
            this.edit_app_panel2__label10.TabIndex = 9;
            this.edit_app_panel2__label10.Text = "hours and ";
            this.edit_app_panel2__label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_label11
            // 
            this.edit_app_panel2_label11.Location = new System.Drawing.Point(187, 209);
            this.edit_app_panel2_label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label11.Name = "edit_app_panel2_label11";
            this.edit_app_panel2_label11.Size = new System.Drawing.Size(47, 25);
            this.edit_app_panel2_label11.TabIndex = 8;
            this.edit_app_panel2_label11.Text = "From:";
            this.edit_app_panel2_label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // edit_app_panel2_from_hours_numericUpDown4
            // 
            this.edit_app_panel2_from_hours_numericUpDown4.Location = new System.Drawing.Point(233, 209);
            this.edit_app_panel2_from_hours_numericUpDown4.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2_from_hours_numericUpDown4.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.edit_app_panel2_from_hours_numericUpDown4.Name = "edit_app_panel2_from_hours_numericUpDown4";
            this.edit_app_panel2_from_hours_numericUpDown4.Size = new System.Drawing.Size(53, 22);
            this.edit_app_panel2_from_hours_numericUpDown4.TabIndex = 7;
            this.edit_app_panel2_from_hours_numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // edit_app_panel2_label12
            // 
            this.edit_app_panel2_label12.Location = new System.Drawing.Point(133, 172);
            this.edit_app_panel2_label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label12.Name = "edit_app_panel2_label12";
            this.edit_app_panel2_label12.Size = new System.Drawing.Size(400, 37);
            this.edit_app_panel2_label12.TabIndex = 6;
            this.edit_app_panel2_label12.Text = "Please, choose the time*";
            this.edit_app_panel2_label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_label13
            // 
            this.edit_app_panel2_label13.AutoSize = true;
            this.edit_app_panel2_label13.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.edit_app_panel2_label13.Location = new System.Drawing.Point(512, 534);
            this.edit_app_panel2_label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label13.Name = "edit_app_panel2_label13";
            this.edit_app_panel2_label13.Size = new System.Drawing.Size(107, 16);
            this.edit_app_panel2_label13.TabIndex = 5;
            this.edit_app_panel2_label13.Text = "* - required fileds";
            this.edit_app_panel2_label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_button3
            // 
            this.edit_app_panel2_button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.edit_app_panel2_button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.edit_app_panel2_button3.Location = new System.Drawing.Point(233, 468);
            this.edit_app_panel2_button3.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2_button3.Name = "edit_app_panel2_button3";
            this.edit_app_panel2_button3.Size = new System.Drawing.Size(200, 37);
            this.edit_app_panel2_button3.TabIndex = 4;
            this.edit_app_panel2_button3.Text = "Confirm the change\r\n";
            this.edit_app_panel2_button3.UseVisualStyleBackColor = false;
            this.edit_app_panel2_button3.Click += new System.EventHandler(this.edit_app_panel2_button3_Click);
            // 
            // edit_app_panel2__label14
            // 
            this.edit_app_panel2__label14.Location = new System.Drawing.Point(200, 111);
            this.edit_app_panel2__label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2__label14.Name = "edit_app_panel2__label14";
            this.edit_app_panel2__label14.Size = new System.Drawing.Size(267, 37);
            this.edit_app_panel2__label14.TabIndex = 3;
            this.edit_app_panel2__label14.Text = "Please, choose the date*";
            this.edit_app_panel2__label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_dateTimePicker1
            // 
            this.edit_app_panel2_dateTimePicker1.Location = new System.Drawing.Point(200, 148);
            this.edit_app_panel2_dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2_dateTimePicker1.Name = "edit_app_panel2_dateTimePicker1";
            this.edit_app_panel2_dateTimePicker1.Size = new System.Drawing.Size(265, 22);
            this.edit_app_panel2_dateTimePicker1.TabIndex = 2;
            this.edit_app_panel2_dateTimePicker1.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            // 
            // edit_app_panel2_label15
            // 
            this.edit_app_panel2_label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.edit_app_panel2_label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_app_panel2_label15.Location = new System.Drawing.Point(133, 37);
            this.edit_app_panel2_label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_panel2_label15.Name = "edit_app_panel2_label15";
            this.edit_app_panel2_label15.Size = new System.Drawing.Size(399, 36);
            this.edit_app_panel2_label15.TabIndex = 1;
            this.edit_app_panel2_label15.Text = "Please, edit your appointment";
            this.edit_app_panel2_label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_panel2_button4
            // 
            this.edit_app_panel2_button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.edit_app_panel2_button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_app_panel2_button4.Location = new System.Drawing.Point(287, 516);
            this.edit_app_panel2_button4.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_panel2_button4.Name = "edit_app_panel2_button4";
            this.edit_app_panel2_button4.Size = new System.Drawing.Size(93, 37);
            this.edit_app_panel2_button4.TabIndex = 0;
            this.edit_app_panel2_button4.Text = "Exit";
            this.edit_app_panel2_button4.UseVisualStyleBackColor = true;
            this.edit_app_panel2_button4.Click += new System.EventHandler(this.edit_app_panel2_button4_Click);
            // 
            // edit_app_button1
            // 
            this.edit_app_button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_app_button1.Location = new System.Drawing.Point(267, 246);
            this.edit_app_button1.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_button1.Name = "edit_app_button1";
            this.edit_app_button1.Size = new System.Drawing.Size(133, 37);
            this.edit_app_button1.TabIndex = 10;
            this.edit_app_button1.Text = "Show";
            this.edit_app_button1.UseVisualStyleBackColor = true;
            this.edit_app_button1.Click += new System.EventHandler(this.edit_app_button1_Click);
            // 
            // edit_app_comboBox1
            // 
            this.edit_app_comboBox1.FormattingEnabled = true;
            this.edit_app_comboBox1.Location = new System.Drawing.Point(200, 209);
            this.edit_app_comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_comboBox1.Name = "edit_app_comboBox1";
            this.edit_app_comboBox1.Size = new System.Drawing.Size(265, 24);
            this.edit_app_comboBox1.TabIndex = 9;
            this.edit_app_comboBox1.SelectedIndexChanged += new System.EventHandler(this.edit_app_comboBox1_SelectedIndexChanged);
            // 
            // edit_app_label2
            // 
            this.edit_app_label2.Location = new System.Drawing.Point(133, 172);
            this.edit_app_label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_label2.Name = "edit_app_label2";
            this.edit_app_label2.Size = new System.Drawing.Size(400, 37);
            this.edit_app_label2.TabIndex = 8;
            this.edit_app_label2.Text = "Please, choose the appoinment to edit\r\n";
            this.edit_app_label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_dateTimePicker1
            // 
            this.edit_app_dateTimePicker1.Location = new System.Drawing.Point(200, 148);
            this.edit_app_dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.edit_app_dateTimePicker1.Name = "edit_app_dateTimePicker1";
            this.edit_app_dateTimePicker1.Size = new System.Drawing.Size(265, 22);
            this.edit_app_dateTimePicker1.TabIndex = 6;
            this.edit_app_dateTimePicker1.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            this.edit_app_dateTimePicker1.ValueChanged += new System.EventHandler(this.edit_app_dateTimePicker1_ValueChanged);
            // 
            // edit_app_label1
            // 
            this.edit_app_label1.Location = new System.Drawing.Point(200, 111);
            this.edit_app_label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_label1.Name = "edit_app_label1";
            this.edit_app_label1.Size = new System.Drawing.Size(267, 37);
            this.edit_app_label1.TabIndex = 5;
            this.edit_app_label1.Text = "Please, choose the date";
            this.edit_app_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_app_welcome
            // 
            this.edit_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.edit_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.edit_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_welcome.Name = "edit_app_welcome";
            this.edit_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.edit_app_welcome.TabIndex = 2;
            this.edit_app_welcome.Text = "Please, select appointment for editing\r\n\r\n";
            this.edit_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_edit_panel_button
            // 
            this.exit_edit_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_edit_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_edit_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_edit_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.exit_edit_panel_button.Name = "exit_edit_panel_button";
            this.exit_edit_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_edit_panel_button.TabIndex = 1;
            this.exit_edit_panel_button.Text = "Exit";
            this.exit_edit_panel_button.UseVisualStyleBackColor = true;
            this.exit_edit_panel_button.Click += new System.EventHandler(this.edit_app_panel_button_Click);
            // 
            // search_panel
            // 
            this.search_panel.Controls.Add(this.search_richTextBox1);
            this.search_panel.Controls.Add(this.search_button1);
            this.search_panel.Controls.Add(this.search_textBox1);
            this.search_panel.Controls.Add(this.search_app_welcome);
            this.search_panel.Controls.Add(this.exit_search_panel_button);
            this.search_panel.Location = new System.Drawing.Point(0, 0);
            this.search_panel.Margin = new System.Windows.Forms.Padding(4);
            this.search_panel.Name = "search_panel";
            this.search_panel.Size = new System.Drawing.Size(667, 615);
            this.search_panel.TabIndex = 10;
            this.search_panel.Visible = false;
            // 
            // search_richTextBox1
            // 
            this.search_richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.search_richTextBox1.Location = new System.Drawing.Point(139, 209);
            this.search_richTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.search_richTextBox1.Name = "search_richTextBox1";
            this.search_richTextBox1.ReadOnly = true;
            this.search_richTextBox1.Size = new System.Drawing.Size(393, 250);
            this.search_richTextBox1.TabIndex = 5;
            this.search_richTextBox1.Text = "";
            // 
            // search_button1
            // 
            this.search_button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search_button1.Location = new System.Drawing.Point(283, 148);
            this.search_button1.Margin = new System.Windows.Forms.Padding(4);
            this.search_button1.Name = "search_button1";
            this.search_button1.Size = new System.Drawing.Size(100, 28);
            this.search_button1.TabIndex = 4;
            this.search_button1.Text = "Search";
            this.search_button1.UseVisualStyleBackColor = true;
            this.search_button1.Click += new System.EventHandler(this.search_button1_Click);
            // 
            // search_textBox1
            // 
            this.search_textBox1.Location = new System.Drawing.Point(133, 111);
            this.search_textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.search_textBox1.Name = "search_textBox1";
            this.search_textBox1.Size = new System.Drawing.Size(399, 22);
            this.search_textBox1.TabIndex = 3;
            // 
            // search_app_welcome
            // 
            this.search_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.search_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.search_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.search_app_welcome.Name = "search_app_welcome";
            this.search_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.search_app_welcome.TabIndex = 2;
            this.search_app_welcome.Text = "Please, enter key words to search";
            this.search_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_search_panel_button
            // 
            this.exit_search_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_search_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_search_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_search_panel_button.Margin = new System.Windows.Forms.Padding(4);
            this.exit_search_panel_button.Name = "exit_search_panel_button";
            this.exit_search_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_search_panel_button.TabIndex = 1;
            this.exit_search_panel_button.Text = "Exit";
            this.exit_search_panel_button.UseVisualStyleBackColor = true;
            this.exit_search_panel_button.Click += new System.EventHandler(this.search_app_panel_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 567);
            this.Controls.Add(this.add_panel);
            this.Controls.Add(this.search_panel);
            this.Controls.Add(this.cancel_panel);
            this.Controls.Add(this.edit_panel);
            this.Controls.Add(this.show_panel);
            this.Controls.Add(this.edit_panel_button);
            this.Controls.Add(this.search__panel_button);
            this.Controls.Add(this.show__panel_button);
            this.Controls.Add(this.cancel__panel_button);
            this.Controls.Add(this.add_panel_button);
            this.Controls.Add(this.main_page_welcome_label);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.add_panel.ResumeLayout(false);
            this.add_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_recurrenceCount_numericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_to_minutes_numericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_to_hours_numericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_from_minutes_numericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_app_from_hours_numericUpDown)).EndInit();
            this.add_app_take_a_look_panel.ResumeLayout(false);
            this.cancel_panel.ResumeLayout(false);
            this.show_panel.ResumeLayout(false);
            this.showing_app_panel.ResumeLayout(false);
            this.edit_panel.ResumeLayout(false);
            this.edit_app_panel2.ResumeLayout(false);
            this.edit_app_panel2.PerformLayout();
            this.edit_take_a_look_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2__to_min_numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2_to_hours_numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2_from_min_numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_app_panel2_from_hours_numericUpDown4)).EndInit();
            this.search_panel.ResumeLayout(false);
            this.search_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label main_page_welcome_label;
        private System.Windows.Forms.Button add_panel_button;
        private System.Windows.Forms.Button cancel__panel_button;
        private System.Windows.Forms.Button show__panel_button;
        private System.Windows.Forms.Button search__panel_button;
        private System.Windows.Forms.Button edit_panel_button;
        private System.Windows.Forms.Panel add_panel;
        private System.Windows.Forms.Label add_app_welcome;
        private System.Windows.Forms.Button exit_add_panel_button;
        private System.Windows.Forms.Panel cancel_panel;
        private System.Windows.Forms.Button exit_cancel_panel_button;
        private System.Windows.Forms.Label cancel_app_welcome;
        private System.Windows.Forms.Panel show_panel;
        private System.Windows.Forms.Panel edit_panel;
        private System.Windows.Forms.Panel search_panel;
        private System.Windows.Forms.Label show_app_welcome;
        private System.Windows.Forms.Button exit_show_panel_button;
        private System.Windows.Forms.Label edit_app_welcome;
        private System.Windows.Forms.Button exit_edit_panel_button;
        private System.Windows.Forms.Label search_app_welcome;
        private System.Windows.Forms.Button exit_search_panel_button;
        private System.Windows.Forms.Label add_app_label_1;
        private System.Windows.Forms.DateTimePicker add_app_dateTimePicker;
        private System.Windows.Forms.Label add_app_label_2;
        private System.Windows.Forms.Button add_app_confirm_button;
        private System.Windows.Forms.Label add_app_label_3;
        private System.Windows.Forms.NumericUpDown add_app_from_hours_numericUpDown;
        private System.Windows.Forms.Label add_app_label_5;
        private System.Windows.Forms.Label add_app_label_4;
        private System.Windows.Forms.NumericUpDown add_app_from_minutes_numericUpDown;
        private System.Windows.Forms.Label add_app_label_6;
        private System.Windows.Forms.Label add_app_label_7;
        private System.Windows.Forms.NumericUpDown add_app_to_minutes_numericUpDown;
        private System.Windows.Forms.NumericUpDown add_app_to_hours_numericUpDown;
        private System.Windows.Forms.Label add_app_label_9;
        private System.Windows.Forms.Label add_app_label_8;
        private System.Windows.Forms.Label add_app_label_11;
        private System.Windows.Forms.RichTextBox add_app_richTextBox;
        private System.Windows.Forms.Label show_app_label_2;
        private System.Windows.Forms.DateTimePicker show_app_dateTimePicker;
        private System.Windows.Forms.Label add_app_label_10;
        private System.Windows.Forms.TextBox add_app_name_input;
        private System.Windows.Forms.Panel add_app_take_a_look_panel;
        private System.Windows.Forms.Label add_app_take_a_look_panel_welcome;
        private System.Windows.Forms.Button exit_add_app_take_a_look;
        private System.Windows.Forms.Button add_app_take_a_look_button;
        private System.Windows.Forms.Label add_app_take_a_look_label_1;
        private System.Windows.Forms.Label add_app_take_a_look_label_2;
        private System.Windows.Forms.Label show_label_1;
        private System.Windows.Forms.ComboBox show_comboBox1;
        private System.Windows.Forms.Button show_app_button1;
        private System.Windows.Forms.Panel showing_app_panel;
        private System.Windows.Forms.Label showing_app_label1;
        private System.Windows.Forms.Label showing_app_label2;
        private System.Windows.Forms.Button showing_app_button2;
        private System.Windows.Forms.Label showing_app_label3;
        private System.Windows.Forms.Button search_button1;
        private System.Windows.Forms.TextBox search_textBox1;
        private System.Windows.Forms.RichTextBox search_richTextBox1;
        private System.Windows.Forms.DateTimePicker edit_app_dateTimePicker1;
        private System.Windows.Forms.Label edit_app_label1;
        private System.Windows.Forms.Label edit_app_label2;
        private System.Windows.Forms.ComboBox edit_app_comboBox1;
        private System.Windows.Forms.Button edit_app_button1;
        private System.Windows.Forms.Panel edit_app_panel2;
        private System.Windows.Forms.Label edit_app_panel2_label5;
        private System.Windows.Forms.RichTextBox edit_app_richTextBox1;
        private System.Windows.Forms.NumericUpDown edit_app_panel2__to_min_numericUpDown1;
        private System.Windows.Forms.NumericUpDown edit_app_panel2_to_hours_numericUpDown2;
        private System.Windows.Forms.Label edit_app_panel2_label6;
        private System.Windows.Forms.Label edit_app_panel2_label7;
        private System.Windows.Forms.Label edit_app_panel2_label8;
        private System.Windows.Forms.Label edit_app_panel2_label9;
        private System.Windows.Forms.NumericUpDown edit_app_panel2_from_min_numericUpDown3;
        private System.Windows.Forms.Label edit_app_panel2__label10;
        private System.Windows.Forms.Label edit_app_panel2_label11;
        private System.Windows.Forms.NumericUpDown edit_app_panel2_from_hours_numericUpDown4;
        private System.Windows.Forms.Label edit_app_panel2_label12;
        private System.Windows.Forms.Label edit_app_panel2_label13;
        private System.Windows.Forms.Button edit_app_panel2_button3;
        private System.Windows.Forms.Label edit_app_panel2__label14;
        private System.Windows.Forms.DateTimePicker edit_app_panel2_dateTimePicker1;
        private System.Windows.Forms.Label edit_app_panel2_label15;
        private System.Windows.Forms.Button edit_app_panel2_button4;
        private System.Windows.Forms.Panel edit_take_a_look_panel;
        private System.Windows.Forms.Label edit_take_a_look_label1;
        private System.Windows.Forms.Label edit_take_a_look_label2;
        private System.Windows.Forms.Button edit_take_a_look_button2;
        private System.Windows.Forms.Label edit_take_a_look_label3;
        private System.Windows.Forms.DateTimePicker cancel_dateTimePicker1;
        private System.Windows.Forms.ComboBox cancel_comboBox1;
        private System.Windows.Forms.Label show_label2;
        private System.Windows.Forms.Label show_label1;
        private System.Windows.Forms.Button cancel_button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox add_app_recurrence_comboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown add_app_recurrenceCount_numericUpDown;
        private System.Windows.Forms.DateTimePicker add_app_recurrenceEndDate_dateTimePicker;
    }
}

