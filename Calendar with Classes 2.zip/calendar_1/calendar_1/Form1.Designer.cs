﻿namespace calendar_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_page_welcome_label = new System.Windows.Forms.Label();
            this.add_panel_button = new System.Windows.Forms.Button();
            this.cancel__panel_button = new System.Windows.Forms.Button();
            this.show__panel_button = new System.Windows.Forms.Button();
            this.search__panel_button = new System.Windows.Forms.Button();
            this.edit_panel_button = new System.Windows.Forms.Button();
            this.add_panel = new System.Windows.Forms.Panel();
            this.add_app_welcome = new System.Windows.Forms.Label();
            this.exit_add_panel_button = new System.Windows.Forms.Button();
            this.cancel_panel = new System.Windows.Forms.Panel();
            this.exit_cancel_panel_button = new System.Windows.Forms.Button();
            this.cancel_app_welcome = new System.Windows.Forms.Label();
            this.show_panel = new System.Windows.Forms.Panel();
            this.show_app_welcome = new System.Windows.Forms.Label();
            this.exit_show_panel_button = new System.Windows.Forms.Button();
            this.edit_panel = new System.Windows.Forms.Panel();
            this.edit_app_welcome = new System.Windows.Forms.Label();
            this.exit_edit_panel_button = new System.Windows.Forms.Button();
            this.search_panel = new System.Windows.Forms.Panel();
            this.search_app_welcome = new System.Windows.Forms.Label();
            this.exit_search_panel_button = new System.Windows.Forms.Button();
            this.add_panel.SuspendLayout();
            this.cancel_panel.SuspendLayout();
            this.show_panel.SuspendLayout();
            this.edit_panel.SuspendLayout();
            this.search_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // main_page_welcome_label
            // 
            this.main_page_welcome_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.main_page_welcome_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_page_welcome_label.Location = new System.Drawing.Point(133, 37);
            this.main_page_welcome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.main_page_welcome_label.Name = "main_page_welcome_label";
            this.main_page_welcome_label.Size = new System.Drawing.Size(399, 36);
            this.main_page_welcome_label.TabIndex = 0;
            this.main_page_welcome_label.Text = "Welcome! Please, choose an option!";
            this.main_page_welcome_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_panel_button
            // 
            this.add_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_panel_button.Location = new System.Drawing.Point(200, 123);
            this.add_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.add_panel_button.Name = "add_panel_button";
            this.add_panel_button.Size = new System.Drawing.Size(267, 37);
            this.add_panel_button.TabIndex = 1;
            this.add_panel_button.Text = "Add new appointment";
            this.add_panel_button.UseVisualStyleBackColor = true;
            this.add_panel_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // cancel__panel_button
            // 
            this.cancel__panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel__panel_button.Location = new System.Drawing.Point(200, 418);
            this.cancel__panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cancel__panel_button.Name = "cancel__panel_button";
            this.cancel__panel_button.Size = new System.Drawing.Size(267, 37);
            this.cancel__panel_button.TabIndex = 2;
            this.cancel__panel_button.Text = "Cancel an appointment";
            this.cancel__panel_button.UseVisualStyleBackColor = true;
            this.cancel__panel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // show__panel_button
            // 
            this.show__panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.show__panel_button.Location = new System.Drawing.Point(200, 345);
            this.show__panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.show__panel_button.Name = "show__panel_button";
            this.show__panel_button.Size = new System.Drawing.Size(267, 37);
            this.show__panel_button.TabIndex = 3;
            this.show__panel_button.Text = "Show appointments";
            this.show__panel_button.UseVisualStyleBackColor = true;
            this.show__panel_button.Click += new System.EventHandler(this.show_button_Click);
            // 
            // search__panel_button
            // 
            this.search__panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search__panel_button.Location = new System.Drawing.Point(200, 271);
            this.search__panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.search__panel_button.Name = "search__panel_button";
            this.search__panel_button.Size = new System.Drawing.Size(267, 37);
            this.search__panel_button.TabIndex = 5;
            this.search__panel_button.Text = "Search an appointment";
            this.search__panel_button.UseVisualStyleBackColor = true;
            this.search__panel_button.Click += new System.EventHandler(this.search_button_Click);
            // 
            // edit_panel_button
            // 
            this.edit_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_panel_button.Location = new System.Drawing.Point(200, 197);
            this.edit_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.edit_panel_button.Name = "edit_panel_button";
            this.edit_panel_button.Size = new System.Drawing.Size(267, 37);
            this.edit_panel_button.TabIndex = 6;
            this.edit_panel_button.Text = "Edit an appointment";
            this.edit_panel_button.UseVisualStyleBackColor = true;
            this.edit_panel_button.Click += new System.EventHandler(this.edit_button_Click);
            // 
            // add_panel
            // 
            this.add_panel.Controls.Add(this.add_app_welcome);
            this.add_panel.Controls.Add(this.exit_add_panel_button);
            this.add_panel.Location = new System.Drawing.Point(1, 0);
            this.add_panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.add_panel.Name = "add_panel";
            this.add_panel.Size = new System.Drawing.Size(667, 615);
            this.add_panel.TabIndex = 4;
            this.add_panel.Visible = false;
            // 
            // add_app_welcome
            // 
            this.add_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.add_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.add_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.add_app_welcome.Name = "add_app_welcome";
            this.add_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.add_app_welcome.TabIndex = 1;
            this.add_app_welcome.Text = "Please, add your appointment";
            this.add_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_add_panel_button
            // 
            this.exit_add_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_add_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_add_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_add_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exit_add_panel_button.Name = "exit_add_panel_button";
            this.exit_add_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_add_panel_button.TabIndex = 0;
            this.exit_add_panel_button.Text = "Exit";
            this.exit_add_panel_button.UseVisualStyleBackColor = true;
            this.exit_add_panel_button.Click += new System.EventHandler(this.exit_add_panel_button_Click);
            // 
            // cancel_panel
            // 
            this.cancel_panel.Controls.Add(this.exit_cancel_panel_button);
            this.cancel_panel.Controls.Add(this.cancel_app_welcome);
            this.cancel_panel.Location = new System.Drawing.Point(0, 0);
            this.cancel_panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cancel_panel.Name = "cancel_panel";
            this.cancel_panel.Size = new System.Drawing.Size(667, 615);
            this.cancel_panel.TabIndex = 7;
            this.cancel_panel.Visible = false;
            // 
            // exit_cancel_panel_button
            // 
            this.exit_cancel_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_cancel_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_cancel_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_cancel_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exit_cancel_panel_button.Name = "exit_cancel_panel_button";
            this.exit_cancel_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_cancel_panel_button.TabIndex = 3;
            this.exit_cancel_panel_button.Text = "Exit";
            this.exit_cancel_panel_button.UseVisualStyleBackColor = true;
            this.exit_cancel_panel_button.Click += new System.EventHandler(this.exit_cancel_panel_button_Click);
            // 
            // cancel_app_welcome
            // 
            this.cancel_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cancel_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.cancel_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cancel_app_welcome.Name = "cancel_app_welcome";
            this.cancel_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.cancel_app_welcome.TabIndex = 2;
            this.cancel_app_welcome.Text = "Please, choose an appointment to be canceled";
            this.cancel_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // show_panel
            // 
            this.show_panel.Controls.Add(this.show_app_welcome);
            this.show_panel.Controls.Add(this.exit_show_panel_button);
            this.show_panel.Location = new System.Drawing.Point(0, 0);
            this.show_panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.show_panel.Name = "show_panel";
            this.show_panel.Size = new System.Drawing.Size(667, 615);
            this.show_panel.TabIndex = 8;
            this.show_panel.Visible = false;
            // 
            // show_app_welcome
            // 
            this.show_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.show_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.show_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.show_app_welcome.Name = "show_app_welcome";
            this.show_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.show_app_welcome.TabIndex = 2;
            this.show_app_welcome.Text = "Please, choose a date";
            this.show_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_show_panel_button
            // 
            this.exit_show_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_show_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_show_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_show_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exit_show_panel_button.Name = "exit_show_panel_button";
            this.exit_show_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_show_panel_button.TabIndex = 1;
            this.exit_show_panel_button.Text = "Exit";
            this.exit_show_panel_button.UseVisualStyleBackColor = true;
            this.exit_show_panel_button.Click += new System.EventHandler(this.show_app_panel_button_Click);
            // 
            // edit_panel
            // 
            this.edit_panel.Controls.Add(this.edit_app_welcome);
            this.edit_panel.Controls.Add(this.exit_edit_panel_button);
            this.edit_panel.Location = new System.Drawing.Point(0, 0);
            this.edit_panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.edit_panel.Name = "edit_panel";
            this.edit_panel.Size = new System.Drawing.Size(667, 615);
            this.edit_panel.TabIndex = 9;
            this.edit_panel.Visible = false;
            // 
            // edit_app_welcome
            // 
            this.edit_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.edit_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.edit_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.edit_app_welcome.Name = "edit_app_welcome";
            this.edit_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.edit_app_welcome.TabIndex = 2;
            this.edit_app_welcome.Text = "Please, select appointment for editing\r\n\r\n";
            this.edit_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_edit_panel_button
            // 
            this.exit_edit_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_edit_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_edit_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_edit_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exit_edit_panel_button.Name = "exit_edit_panel_button";
            this.exit_edit_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_edit_panel_button.TabIndex = 1;
            this.exit_edit_panel_button.Text = "Exit";
            this.exit_edit_panel_button.UseVisualStyleBackColor = true;
            this.exit_edit_panel_button.Click += new System.EventHandler(this.edit_app_panel_button_Click);
            // 
            // search_panel
            // 
            this.search_panel.Controls.Add(this.search_app_welcome);
            this.search_panel.Controls.Add(this.exit_search_panel_button);
            this.search_panel.Location = new System.Drawing.Point(0, 0);
            this.search_panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.search_panel.Name = "search_panel";
            this.search_panel.Size = new System.Drawing.Size(667, 615);
            this.search_panel.TabIndex = 10;
            this.search_panel.Visible = false;
            // 
            // search_app_welcome
            // 
            this.search_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.search_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_app_welcome.Location = new System.Drawing.Point(133, 37);
            this.search_app_welcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.search_app_welcome.Name = "search_app_welcome";
            this.search_app_welcome.Size = new System.Drawing.Size(399, 36);
            this.search_app_welcome.TabIndex = 2;
            this.search_app_welcome.Text = "Please, enter key words to search";
            this.search_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_search_panel_button
            // 
            this.exit_search_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_search_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_search_panel_button.Location = new System.Drawing.Point(287, 516);
            this.exit_search_panel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exit_search_panel_button.Name = "exit_search_panel_button";
            this.exit_search_panel_button.Size = new System.Drawing.Size(93, 37);
            this.exit_search_panel_button.TabIndex = 1;
            this.exit_search_panel_button.Text = "Exit";
            this.exit_search_panel_button.UseVisualStyleBackColor = true;
            this.exit_search_panel_button.Click += new System.EventHandler(this.search_app_panel_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 567);
            this.Controls.Add(this.add_panel);
            this.Controls.Add(this.show_panel);
            this.Controls.Add(this.search_panel);
            this.Controls.Add(this.edit_panel);
            this.Controls.Add(this.cancel_panel);
            this.Controls.Add(this.edit_panel_button);
            this.Controls.Add(this.search__panel_button);
            this.Controls.Add(this.show__panel_button);
            this.Controls.Add(this.cancel__panel_button);
            this.Controls.Add(this.add_panel_button);
            this.Controls.Add(this.main_page_welcome_label);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.add_panel.ResumeLayout(false);
            this.cancel_panel.ResumeLayout(false);
            this.show_panel.ResumeLayout(false);
            this.edit_panel.ResumeLayout(false);
            this.search_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label main_page_welcome_label;
        private System.Windows.Forms.Button add_panel_button;
        private System.Windows.Forms.Button cancel__panel_button;
        private System.Windows.Forms.Button show__panel_button;
        private System.Windows.Forms.Button search__panel_button;
        private System.Windows.Forms.Button edit_panel_button;
        private System.Windows.Forms.Panel add_panel;
        private System.Windows.Forms.Label add_app_welcome;
        private System.Windows.Forms.Button exit_add_panel_button;
        private System.Windows.Forms.Panel cancel_panel;
        private System.Windows.Forms.Button exit_cancel_panel_button;
        private System.Windows.Forms.Label cancel_app_welcome;
        private System.Windows.Forms.Panel show_panel;
        private System.Windows.Forms.Panel edit_panel;
        private System.Windows.Forms.Panel search_panel;
        private System.Windows.Forms.Label show_app_welcome;
        private System.Windows.Forms.Button exit_show_panel_button;
        private System.Windows.Forms.Label edit_app_welcome;
        private System.Windows.Forms.Button exit_edit_panel_button;
        private System.Windows.Forms.Label search_app_welcome;
        private System.Windows.Forms.Button exit_search_panel_button;
    }
}

