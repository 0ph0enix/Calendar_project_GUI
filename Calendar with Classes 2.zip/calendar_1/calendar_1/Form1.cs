﻿/*
   Author: Anton Tikhonov
   Version: 1.1
   Date Modified: November 14, 2024
   Description of change: Creating a menu that hopes us to different panels. With all of them
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppointmentNameSpace;

namespace calendar_1
{
    public partial class Form1 : Form
    {
//      <==========================>        
//      All creation methods below:
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e) 
        {

        }
//      Creation methods located above
//      <==============================>       

//      <==============================>        
//      All buttons methods below:
        private void add_button_Click(object sender, EventArgs e) 
        {
            add_panel.Show();
        }
        private void exit_add_panel_button_Click(object sender, EventArgs e)
        {
            add_panel.Hide();
        }
        private void show_button_Click(object sender, EventArgs e) 
        {
            show_panel.Show();
        }
        private void show_app_panel_button_Click(object sender, EventArgs e)
        {
            show_panel.Hide();
        }
        private void edit_button_Click(object sender, EventArgs e)
        {
            edit_panel.Show();
        }
        private void edit_app_panel_button_Click(object sender, EventArgs e)
        {
            edit_panel.Hide();
        }
        private void search_button_Click(object sender, EventArgs e)
        {
            search_panel.Show();
        }
        private void search_app_panel_button_Click(object sender, EventArgs e)
        {
            search_panel.Hide();
        }
        private void cancel_button_Click(object sender, EventArgs e)
        {
            cancel_panel.Show();
        }
        private void exit_cancel_panel_button_Click(object sender, EventArgs e)
        {
            cancel_panel.Hide();
        }
 //      Buttons methods located above
 //      <=============================>
 

    }
}
