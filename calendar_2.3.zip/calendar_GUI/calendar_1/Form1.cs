﻿/*
    Author: Anton Tikhonov,Josiah Hoppe, Leah Proehl.
    Current version: 2.3
    Date Modified: November 19, 2024
    Description of change 1.1 (11/14): Creating a menu that hopes us to different panels. With all of them
    Description of change 2.0 (11/19): Adding complete add_appointment panel. 
    Description of change 2.1 (11/19): Adding name to add_appointment panel and new panel that shows conformation after submitting 
                                       an appointment, promps to add more and if not resseting all data to default
    Description of change 2.2 (11/19): Adding drop-down box to show app, working on findint if we can put data there to show.
    Description of change 2.3 (11/25): Adding change and show panels functions. 
   
    FIX THAT
        1) Make sure that drop down box only show app on the correct date.
        2) Show stuff at show_app_panel
        3) How to use vertical scroll bar on shearch panel
        4) Edit and cancel panels are not there yet
        5) Add a way to display things at search panel 
        6) We don't grab the year
        7) We need to change the way we input data to classes
    Potential/future to do:
        1) Accept not only numeric end time, but also duration.
        2) Connect with classes duh
        3) Other features like overlap warnings, recurring events etc
        4) Add checkbox for all day appointments in the Add Appointment panel
        
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calendar_2
{
    public partial class Form1 : Form
    {
//      <==========================>        
//      All creation methods below:
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e) 
        {

        }
//      Creation methods located above
//      <==============================>       

//      <==============================>        
//      All buttons methods below:
        private void add_button_Click(object sender, EventArgs e) 
        {
            add_panel.Show();
        }
        private void exit_add_panel_button_Click(object sender, EventArgs e)
        {
            add_panel.Hide();
        }
        private void show_button_Click(object sender, EventArgs e) 
        {
            show_panel.Show();
        }
        private void show_app_panel_button_Click(object sender, EventArgs e)
        {
            show_panel.Hide();
        }
        private void edit_button_Click(object sender, EventArgs e)
        {
            edit_panel.Show();
        }
        private void edit_app_panel_button_Click(object sender, EventArgs e)
        {
            edit_panel.Hide();
        }
        private void search_button_Click(object sender, EventArgs e)
        {
            search_panel.Show();
        }
        private void search_app_panel_button_Click(object sender, EventArgs e)
        {
            search_panel.Hide();
        }
        private void cancel_button_Click(object sender, EventArgs e)
        {
            cancel_panel.Show();
        }
        private void exit_cancel_panel_button_Click(object sender, EventArgs e)
        {
            cancel_panel.Hide();
        }
        private void add_app_confirm_button_Click(object sender, EventArgs e)
        {
            // confirm an appointment button so creation
            // of the class instance must be here
            add_app_take_a_look_panel.Show();
            string output = String.Format
                ("Your appointment {0} on {1} {2} starts at {3}:{4} and ends at {5}:{6}", 
                name, month, day, from_hour, from_minute, to_hour, to_minute);
            add_app_take_a_look_label_1.Text = output;
            add_app_take_a_look_label_2.Text = "Your description: " + description;
            show_comboBox1.Items.Add(name); // That should be replaced with .Add(Obejct.getName) or smth like that
        }
        private void exit_add_app_take_a_look_panel_Click(object sender, EventArgs e)
        {
            add_app_take_a_look_panel.Hide();
            add_panel.Hide();
            // resetting all the data after user left
            add_app_richTextBox.Text = "";
            add_app_name_input.Text = "";
            add_app_dateTimePicker.Value = new DateTime(2025, 1, 1);
            add_app_from_minutes_numericUpDown.Value = 0;
            add_app_to_minutes_numericUpDown.Value = 0;
            add_app_from_hours_numericUpDown.Value = 0;
            add_app_to_hours_numericUpDown.Value = 0;
        }
        private void add_app_take_a_look_button_Click(object sender, EventArgs e)
        {
            add_app_take_a_look_panel.Hide();
        }
        private void show_app_button1_Click(object sender, EventArgs e)
        {
            showing_the_app_panel.Show();
        }
        private void showing_the_app_button2_Click(object sender, EventArgs e)
        {
            showing_the_app_panel.Hide();
            show_panel.Hide();
        }
        private void search_button1_Click(object sender, EventArgs e)
        {

        }
        private void edit_app_button1_Click(object sender, EventArgs e)
        {
            edit_app_panel2.Show();
        }
        private void edit_app_panel2_button4_Click(object sender, EventArgs e)
        {
            edit_panel.Hide();
            edit_app_panel2.Hide();
            edit_take_a_look_panel.Hide();
        }
        //      Buttons methods located above
        //      <=============================>

        //      <==============================>        
        //      Getting data from user to create app methods below:

        decimal from_hour, to_hour, from_minute, to_minute;
        string description, name, date, month, day;

        private void show_comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //choosing the appointment in show panel
        }

        private void add_app_richTextBox_TextChanged(object sender, EventArgs e)
        {
            description = add_app_richTextBox.Text;
        }

        private void add_app_name_input_TextChanged(object sender, EventArgs e)
        {
            name = add_app_name_input.Text;
        }

        private void edit_app_panel2_button3_Click(object sender, EventArgs e)
        {
            edit_take_a_look_panel.Show();
        }

        private void edit_take_a_look_button2_Click(object sender, EventArgs e)
        {
            edit_panel.Hide();
            edit_app_panel2.Hide();
            edit_take_a_look_panel.Hide();
     
        }

        private void cancel_button1_Click(object sender, EventArgs e)
        {
            cancel_panel.Hide();
        }

        private void add_app_dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            date = add_app_dateTimePicker.Value.ToString("yyyy-MM-dd");
            month = add_app_dateTimePicker.Value.Month.ToString();
            day = add_app_dateTimePicker.Value.Day.ToString();
            switch (month)
            {
                case "1":
                    month = "January";
                    break;
                case "2":
                    month = "February";
                    break;
                case "3":
                    month = "March";
                    break;
                case "4":
                    month = "April";
                    break;
                case "5":
                    month = "May";
                    break;
                case "6":
                    month = "June";
                    break;
                case "7":
                    month = "July";
                    break;
                case "8":
                    month = "August";
                    break;
                case "9":
                    month = "September";
                    break;
                case "10":
                    month = "October";
                    break;
                case "11":
                    month = "November";
                    break;
                case "12":
                    month = "December";
                    break;
            }
        }
        private void add_app_from_minutes_numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            from_minute = add_app_from_minutes_numericUpDown.Value;
        }
        private void add_app__from_hours_numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            from_hour = add_app_from_hours_numericUpDown.Value;
        }
        private void add_app_to_minutes_numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            to_minute = add_app_to_minutes_numericUpDown.Value;
        }
        private void add_app_to_hours_numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            to_hour = add_app_to_hours_numericUpDown.Value;
        }
        //      Getting data from user to create app is above
        //      <=============================>


        //      Edit methods located below
        //      <==============================>   

        private void edit_app_comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void edit_app_dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
        //      Edit thigs are located above
        //      <==============================>     
    }
}
