﻿/* Author: Josiah Hoppe
 * Date: Nov 25, 2024
 * Purpose: This part of the program that creates Appointment objects from user input.
 */

using System.Collections.Generic;

namespace AppointmentNameSpace {
    public class Appointment
    {
        private AppointmentDate Day { get; set; }
        private AppointmentTime From { get; set; }
        private AppointmentTime To { get; set; }

        private string Title { get; set; }

        public string Description {get ; set ;}
        /**
           Constructs an Appointment object.
        */
        public Appointment(string s, string description = "")
        {
            string[] tokens = s.Split(' ');
            int titleCount = tokens.Length - 3;
            Title = tokens[0];
            for (int i = 1; i < titleCount; i++)
            {
                Title += " " + tokens[i];
            }
 
            Day = new AppointmentDate(tokens[tokens.Length - 3]);
            From = new AppointmentTime(tokens[tokens.Length - 2]);
            To = new AppointmentTime(tokens[tokens.Length - 1]);

            Description = description;
        }

        /**
           Determines if this appointment is the same as another appointment.
           @param other the other appointment
           @return true if the appointments are equal, false otherwise
        */
        public override bool Equals(object other)
        {
            if (other == null)
                return false;
            Appointment b = (Appointment)other;

            return Title.Equals(b.Title) &&
               Day.Equals(b.Day) &&
               From.Equals(b.From) &&
               To.Equals(b.To) &&
               Description.Equals(b.Description);
        }

        /**
           Determines if an appointment falls on a certain Day.
           @param d the appointment date
           @return true if the appointment date falls on a
               certain Day false, otherwise
        */
        public bool FallsOn(AppointmentDate d)
        {
            return Day.Equals(d);
        }

        /**
           Return a string representation
        */
        public override string ToString()
        {
            return Title + " " + Day + " " + From + " " + To + " " + Description;
        }

        public override int GetHashCode()
        {
            return (Title + " " + Day + " " + From + " " + To + Description).GetHashCode();
        }
    }
}