﻿namespace calendar_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_page_welcome_label = new System.Windows.Forms.Label();
            this.add_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.show_button = new System.Windows.Forms.Button();
            this.search_button = new System.Windows.Forms.Button();
            this.edit_button = new System.Windows.Forms.Button();
            this.add_panel = new System.Windows.Forms.Panel();
            this.exit_add_panel_button = new System.Windows.Forms.Button();
            this.add_app_welcome = new System.Windows.Forms.Label();
            this.add_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // main_page_welcome_label
            // 
            this.main_page_welcome_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.main_page_welcome_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_page_welcome_label.Location = new System.Drawing.Point(100, 30);
            this.main_page_welcome_label.Name = "main_page_welcome_label";
            this.main_page_welcome_label.Size = new System.Drawing.Size(300, 30);
            this.main_page_welcome_label.TabIndex = 0;
            this.main_page_welcome_label.Text = "Welcome! Please, choose an option!";
            this.main_page_welcome_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // add_button
            // 
            this.add_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_button.Location = new System.Drawing.Point(150, 100);
            this.add_button.Name = "add_button";
            this.add_button.Size = new System.Drawing.Size(200, 30);
            this.add_button.TabIndex = 1;
            this.add_button.Text = "Add new appointment";
            this.add_button.UseVisualStyleBackColor = true;
            this.add_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel_button.Location = new System.Drawing.Point(150, 340);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(200, 30);
            this.cancel_button.TabIndex = 2;
            this.cancel_button.Text = "Cancel an appointment";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // show_button
            // 
            this.show_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.show_button.Location = new System.Drawing.Point(150, 280);
            this.show_button.Name = "show_button";
            this.show_button.Size = new System.Drawing.Size(200, 30);
            this.show_button.TabIndex = 3;
            this.show_button.Text = "Show appointments";
            this.show_button.UseVisualStyleBackColor = true;
            this.show_button.Click += new System.EventHandler(this.show_button_Click);
            // 
            // search_button
            // 
            this.search_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search_button.Location = new System.Drawing.Point(150, 220);
            this.search_button.Name = "search_button";
            this.search_button.Size = new System.Drawing.Size(200, 30);
            this.search_button.TabIndex = 5;
            this.search_button.Text = "Search an appointment";
            this.search_button.UseVisualStyleBackColor = true;
            this.search_button.Click += new System.EventHandler(this.search_button_Click);
            // 
            // edit_button
            // 
            this.edit_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_button.Location = new System.Drawing.Point(150, 160);
            this.edit_button.Name = "edit_button";
            this.edit_button.Size = new System.Drawing.Size(200, 30);
            this.edit_button.TabIndex = 6;
            this.edit_button.Text = "Edit an appointment";
            this.edit_button.UseVisualStyleBackColor = true;
            this.edit_button.Click += new System.EventHandler(this.edit_button_Click);
            // 
            // add_panel
            // 
            this.add_panel.Controls.Add(this.add_app_welcome);
            this.add_panel.Controls.Add(this.exit_add_panel_button);
            this.add_panel.Location = new System.Drawing.Point(1, 1);
            this.add_panel.Name = "add_panel";
            this.add_panel.Size = new System.Drawing.Size(487, 464);
            this.add_panel.TabIndex = 4;
            this.add_panel.Visible = false;
            // 
            // exit_add_panel_button
            // 
            this.exit_add_panel_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit_add_panel_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit_add_panel_button.Location = new System.Drawing.Point(215, 419);
            this.exit_add_panel_button.Name = "exit_add_panel_button";
            this.exit_add_panel_button.Size = new System.Drawing.Size(70, 30);
            this.exit_add_panel_button.TabIndex = 0;
            this.exit_add_panel_button.Text = "Exit";
            this.exit_add_panel_button.UseVisualStyleBackColor = true;
            this.exit_add_panel_button.Click += new System.EventHandler(this.exit_add_panel_button_Click);
            // 
            // add_app_welcome
            // 
            this.add_app_welcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.add_app_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_app_welcome.Location = new System.Drawing.Point(100, 30);
            this.add_app_welcome.Name = "add_app_welcome";
            this.add_app_welcome.Size = new System.Drawing.Size(300, 30);
            this.add_app_welcome.TabIndex = 1;
            this.add_app_welcome.Text = "Please, add your appointment.";
            this.add_app_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.add_panel);
            this.Controls.Add(this.edit_button);
            this.Controls.Add(this.search_button);
            this.Controls.Add(this.show_button);
            this.Controls.Add(this.cancel_button);
            this.Controls.Add(this.add_button);
            this.Controls.Add(this.main_page_welcome_label);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.add_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label main_page_welcome_label;
        private System.Windows.Forms.Button add_button;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.Button show_button;
        private System.Windows.Forms.Button search_button;
        private System.Windows.Forms.Button edit_button;
        private System.Windows.Forms.Panel add_panel;
        private System.Windows.Forms.Label add_app_welcome;
        private System.Windows.Forms.Button exit_add_panel_button;
    }
}

